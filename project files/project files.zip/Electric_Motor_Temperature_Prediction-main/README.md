# Electric_Motor_Temperature_Prediction
DEMO VIDEO CLICK HERE : https://drive.google.com/file/d/1TC6N9YbZO9w97CHVql8hXJZxt_ovRR9l/view?usp=drive_link
